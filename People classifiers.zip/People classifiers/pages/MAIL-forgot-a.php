<html><body>
  <a href="<?=$link?>">Click here to reset your password.</a>
</body></html>