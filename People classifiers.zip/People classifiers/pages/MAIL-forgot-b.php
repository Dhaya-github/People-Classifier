<html><body>
  Your new password is <strong><?=$password?></strong>
</body></html>