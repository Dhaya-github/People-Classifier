<html><body>
  <a href="<?=$link?>">Click here to activate your account.</a>
</body></html>